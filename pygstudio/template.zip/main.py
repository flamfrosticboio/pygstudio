# // Pygstudio template file created by pygstudio script (Version 2.0)
# ? You are free to edit this script, especially comments

import engine

engine.start()
