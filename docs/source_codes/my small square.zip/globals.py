# // Pygstudio template file created by pygstudio script (Version 1.0)

# Note: You are free to edit this script as it is intended to be edited
#       You may also delete other comments in this script
#       Add other variables here as globals

from typing import Optional
import pygame

running: bool = False

clock: pygame.time.Clock = pygame.time.Clock()
screen: Optional[pygame.Surface] = None

from components import game_classes
movement_map = [False, False, False, False]
player = game_classes.Player((0, 0))

# === Optional functions ===

# def get_screen() -> Optional[pygame.Surface]:
#     if screen is None and debug_mode == True:
#         print("PYGSTUDIO WARNING: Game is not yet initialized!")
#     return screen

# === Bindable functions (Required most of the time) ===
# These bindable functions can be setted outside this script
# and add initialization code at 'on_init()' function that will
# set these functions outside the script

def on_event(event: pygame.event.Event) -> None:
    if event.type == pygame.KEYDOWN:
        if event.key == pygame.K_LEFT: movement_map[0] = True
        if event.key == pygame.K_UP: movement_map[1] = True
        if event.key == pygame.K_DOWN: movement_map[2] = True
        if event.key == pygame.K_RIGHT: movement_map[3] = True
    elif event.type == pygame.KEYUP:
        if event.key == pygame.K_LEFT: movement_map[0] = False
        if event.key == pygame.K_UP: movement_map[1] = False
        if event.key == pygame.K_DOWN: movement_map[2] = False
        if event.key == pygame.K_RIGHT: movement_map[3] = False

def on_render(screen: pygame.Surface) -> None:
    if movement_map[0]: player.rect.x += -3
    if movement_map[1]: player.rect.y += -3
    if movement_map[2]: player.rect.y += 3
    if movement_map[3]: player.rect.x += 3

    screen.blit(player.image, player.rect)

def on_init() -> None:
    # This bindable function is executed before the window initialization
    
    # === Outside setter code template (to make your day easier) === # 
    # from components import SETTER
    pass

def on_init_window():
    # This bindable function is executed after the window initialization
    pass

def on_exit():
    # This bindable function is executed when the game exits
    pass