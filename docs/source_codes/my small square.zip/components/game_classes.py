import pygame

class Player:
    def __init__(self, position):
        self.image = pygame.Surface((20, 20))
        self.rect = pygame.Rect(position, (20, 20))