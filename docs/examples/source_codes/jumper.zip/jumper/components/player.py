import pygame as pg

class Player:
    def __init__(self, pos) -> None:
        self.image = pg.Surface((20, 20))
        self.rect = pg.Rect(pos, (20, 20))
        
    def render(self, surface):
        surface.blit(self.image, self.rect)
        
class Block:
    def __init__(self, pos, size):
        self.image = pg.Surface(size)
        self.rect = pg.Rect(pos, size)
        
    def render(self, surface):
        surface.blit(self.image, self.rect)