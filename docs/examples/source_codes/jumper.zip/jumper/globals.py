# // Pygstudio template file created by pygstudio script (Version 1.1)
# ? You are free to edit this script

from typing import Optional
import pygame

running: bool = False

clock: pygame.time.Clock = pygame.time.Clock()
screen: Optional[pygame.Surface] = None

from components.player import Player, Block
player = Player((200, 50))
mvmap = [False, False, False]
blocks = [
    Block((10, 400), (200, 10)),
    Block((450, 400), (200, 10)),
    Block((200, 375), (250, 10))
]

PLAYER_SPEED = 3
PLAYER_JUMPPOWER = 5
AIRTIME_THRESHOLD = 3
FRICTION = 0.8
GRAVITY = 20

player_vel_x = 0
player_vel_y = 0 
air_time = 0

def on_event(event: pygame.event.Event) -> None:
    global player_vel_x, player_vel_y
    if event.type == pygame.KEYDOWN:
        if event.key == pygame.K_UP: mvmap[0] = True
        elif event.key == pygame.K_LEFT: mvmap[1] = True
        elif event.key == pygame.K_RIGHT: mvmap[2] = True
    elif event.type == pygame.KEYUP:
        if event.key == pygame.K_UP: mvmap[0] = False
        elif event.key == pygame.K_LEFT: mvmap[1] = False
        elif event.key == pygame.K_RIGHT: mvmap[2] = False

def on_render(screen: pygame.Surface) -> None:
    for block in blocks: block.render(screen)
    player.render(screen)

def on_init():
    # This bindable function is executed after the window initialization
    pass

def on_exit():
    # This bindable function is executed when the game exits
    pass