from time import time, sleep
import globals
# it is also possible to do `from globals import *`

fps = 1/60
last_dt = 0

while globals.running:
    # A good game developer always use delta time for physics and animation (dt)
    dt = time() - last_dt
    
    if globals.mvmap[0] and globals.air_time <= globals.AIRTIME_THRESHOLD: 
        globals.player_vel_y = -globals.PLAYER_JUMPPOWER
    
    if globals.mvmap[1] and globals.mvmap[2]: pass
    elif globals.mvmap[1]: globals.player_vel_x = -globals.PLAYER_SPEED
    elif globals.mvmap[2]: globals.player_vel_x = globals.PLAYER_SPEED
    
    globals.player_vel_y += (globals.GRAVITY * fps)
    globals.player.rect.y += int(globals.player_vel_y)
    globals.air_time += 1
    
    # Checking collision at y level
    for block in globals.blocks:
        collided = globals.player.rect.colliderect(block.rect)
        if collided:
            globals.player_vel_y = 0
            globals.air_time = 0
            globals.player.rect.bottom = block.rect.top
            
    globals.player.rect.x += int(globals.player_vel_x)
    globals.player_vel_x *= globals.FRICTION
    
    # Checking collision at x level
    for block in globals.blocks:
        collided = globals.player.rect.colliderect(block.rect)
        if collided:
            if globals.player_vel_x > 0:
                globals.player.rect.right = block.rect.left
            elif globals.player_vel_x < 0:
                globals.player.rect.left = block.rect.right
            globals.player_vel_x = 0
    
    last_dt = time()
    sleep(fps)